#pragma warning disable CS8618
using System.ComponentModel.DataAnnotations;
namespace csharp_proj.Models;
public class IndexViewModel
{
    // public Review NewReview {get;set;}
    public Comment NewComment {get;set;}
}